<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/User.php';

    $database = new Database();
    $db = $database->getConnection();

    $yes = new User($db);
	$hex_key = bin2hex ( 'roboads' ); 

	$abCrypt = new abCrypt($hex_key);
$user_ID = "";
$rule  = "";
$fileToUpload = "";
$name  ="";
$email = "";
$username ="";
$password  = "";
$gender = "";
$age = "";
$country_code = "";
$mob_no = "";
$country = "";
$OS = "";
$device_ID = "";
$device_token = "";
$location = "";
$image = "";
$access_mode = "";
$final_otp = "";

$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Insert start
// get posted data
$user_ID =$_POST["user_ID"];
$rule  =$_POST["rule"];
$fileToUpload  =$_POST["fileToUpload"];
$name  =$_POST["name"];
$email =$_POST["email"];
$username =$_POST["username"];
$password  =$_POST["password"];
$gender =$_POST["gender"];
$age =$_POST["age"];
$country_code =$_POST["country_code"];
$mob_no = $_POST["mob_no"];
$country = $_POST["country"];
$OS = $_POST["OS"];
$device_ID = $_POST["device_ID"];
$device_token = $_POST["device_token"];
$location =$_POST["location"];
$image = $_POST["image"];
$access_mode = $_POST["access_mode"];
$final_otp =$_POST["final_otp"];

// set product property values
$encrypted_txt = $abCrypt->encrypt($password);

$decrypted_txt = $abCrypt->decrypt($encrypted_txt);


$yes->user_ID = $user_ID;
$yes->name = $name;
$yes->email = $email;
$yes->username = $username;
$yes->password = $encrypted_txt;

$yes->gender = $gender;
$yes->age = $age;
$yes->country_code = $country_code;
$yes->mob_no = $mob_no;

$yes->country = $country;
$yes->OS = $OS;
$yes->device_ID = $device_ID;
$yes->device_token = $device_token;

$yes->location = $location;
$yes->image = $image;
$yes->access_mode = $access_mode;
$yes->final_otp = $final_otp;

// ........................................................signin rule
if($rule == "signin")
{

$stmt = $yes->existUser();
$Count = $stmt->rowCount();
	
	if($Count > 0){
		
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
			$p = $password;
			$decrypted_txt = $abCrypt->decrypt($p);
			//echo $decrypted_txt;
			if ($decrypted_txt == $_POST["password"])
			{
				$UserArr = array();
				$UserArr["status"] = "1";
				$UserArr["message"] = "Login Successfully ";
				$stmt1 = $yes->updateDevice();
				//echo $stmt1;
				if ($stmt1){
					
					
					$s = $yes->existUser();
					$C = $s->rowCount();
	
	
	if($C > 0){
				
				
        while ($r = $s->fetch(PDO::FETCH_ASSOC)){
            extract($r);
           $UserArr["body"] = [
                "user_ID" => $user_ID,
                "name" => $name,
                "email" => $email,
                "username" => $username,
                //"password" => $password,
				
						"gender" => $gender, 
                        "age" => $age, 
                        "country_code" => $country_code, 
                        "mob_no" => $mob_no,
						
						"country" => $country, 
                        "OS" => $OS, 
                        "device_ID" => $device_ID, 
                        "device_token" => $device_token,
						
						"location" => $location, 
                        "image" => $image, 
                        "access_mode" => $access_mode, 
                        "final_otp" => $final_otp			
		];

            
        }
        echo json_encode($UserArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
					
				
				
			} else{
        http_response_code(404);
        echo json_encode(
            array("message" => "Device ID not updated")
        );
    }
        }
		
        
		
		
	}
	}
	 else{
        http_response_code(404);
        echo json_encode(
            array("status" => "0", "message" => "Invalid Credentials")
        );
    }
}
// ........................................................image rule
if($rule == "image_upload")
{
	
	
	if($rule == "image_upload")
	{
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
   // echo "File is an image - " . $check["mime"] . ".";
   $heroes["message"] = "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    //echo "File is not an image.";
	$heroes["message"] = "File is not an image.";
	
    $uploadOk = 0;
  }
//If the file is larger than 500KB  
if ($_FILES["fileToUpload"]["size"] > 500000) {
  //echo "Sorry, your file is too large.";
  $heroes["message"] = "Sorry, your file is too large.";
  
  $uploadOk = 0;
}
  
}

// Check if file already exists
// Check file size

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $heroes["message"] = "An error occurred while uploading the image";
  
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.<br><br>";
	$heroes["message"] = " The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
	$heroes["path_url"] = "http:/190.168.0.203/aqses/api/".$target_file;
	$heroes["status"] = "1";
	
	$img = $heroes["path_url"];
	$f= $img[4];
	$final = "<a href= " .$target_file. ">" .$f. "</a>";
	//echo $final;
	$sql = "insert into image(image) values('$img');";
	
	
	mysqli_query($con,$sql);
	
	
	
	
	//echo "<br><br><br>";
  } else {
    //echo "Sorry, there was an error uploading your file.";
	$heroes["message"] = "Sorry, there was an error uploading your file.";
    
  }

}
echo json_encode($heroes);
	
}


//.......................................Signup rule ...................

if($rule == "signup"){
//check if user exists
$r = $yes->existUser();
$Count = $r->rowCount();
	
     json_encode($Count);
	 
if($Count > 0){
echo json_encode(
            array("status" => "0", "message" => "User already exists")
        );
}
else{
// insert the data
if($yes->createUser()){

	$stmt = $yes->getdata();
    $Count = $stmt->rowCount();
	
	
	if($Count > 0){
        
        $UserArr = array();
		$UserArr["status"] = "1";
		$UserArr["message"] = "User Registered Successfully ";
        
        

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
           $UserArr["body"] = [
                "user_ID" => $user_ID,
                "name" => $name,
                "email" => $email,
                "username" => $username,
                "password" => $password,
				
						"gender" => $gender, 
                        "age" => $age, 
                        "country_code" => $country_code, 
                        "mob_no" => $mob_no,
						
						"country" => $country, 
                        "OS" => $OS, 
                        "device_ID" => $device_ID, 
                        "device_token" => $device_token,
						
						"location" => $location, 
                        "image" => $image, 
                        "access_mode" => $access_mode, 
                        "final_otp" => $final_otp			
		];

            
        }
        echo json_encode($UserArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }

}

// if unable to insert the product, tell the user
else{
echo json_encode(
            array("status" => "0", "message" => "User Not Registered")
        );
}
}
}
//Insert End
//.....................................................read rule
if($rule == "getProfile")
{
    $stmt = $yes->getProfile();
    $itemCount = $stmt->rowCount();
	//echo $itemCount;

     json_encode($itemCount);

    if($itemCount > 0){
        $UserArr = array();
		$UserArr["status"] = "1";
		$UserArr["message"] = "User profile";
        
        

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
           $UserArr["body"] = [
                "user_ID" => $user_ID,
                "name" => $name,
                "email" => $email,
                "username" => $username,
                "password" => $password,
				
						"gender" => $gender, 
                        "age" => $age, 
                        "country_code" => $country_code, 
                        "mob_no" => $mob_no,
						
						"country" => $country, 
                        "OS" => $OS, 
                        "device_ID" => $device_ID, 
                        "device_token" => $device_token,
						
						"location" => $location, 
                        "image" => $image, 
                        "access_mode" => $access_mode, 
                        "final_otp" => $final_otp			
		];

            
        }
        echo json_encode($UserArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("status" => "0", "message" => "No record found.")
        );
    }
	}
if($rule == "updateProfile")
{	

	
					$s = $yes->updateProfile();
					//echo $s;
	if($s){
		$UserArr = array();
		$UserArr["status"] = "1";
		$UserArr["message"] = "User Profile Updated ";
		$ss = $yes->existUser();
		$C = $ss->rowCount();
	
	if($C > 0){
				
				
        while ($r = $ss->fetch(PDO::FETCH_ASSOC)){
            extract($r);
           $UserArr["body"] = [
                "user_ID" => $user_ID,
                "name" => $name,
                "email" => $email,
                "username" => $username,
                "password" => $password,
				
						"gender" => $gender, 
                        "age" => $age, 
                        "country_code" => $country_code, 
                        "mob_no" => $mob_no,
						
						"country" => $country, 
                        "OS" => $OS, 
                        "device_ID" => $device_ID, 
                        "device_token" => $device_token,
						
						"location" => $location, 
                        "image" => $image, 
                        "access_mode" => $access_mode, 
                        "final_otp" => $final_otp			
		];

            
        }
        echo json_encode($UserArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("status" => "0", "message" => "Profile not Updated.")
        );
    }

}
}
?>

