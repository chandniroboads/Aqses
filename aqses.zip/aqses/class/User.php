<?php
    class User{

        // Connection
        private $conn;

        // Table
        private $db_table = "user_directory";

        // Columns
		
        public $user_ID;
        public $name;
        public $email;
        public $username;
        public $password;
        

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        } 

        // GET ALL
        public function getUser(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
			
            return $stmt;
        }
		//GET registered data
		
		public function getdata(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " where username = :username";
            $stmt = $this->conn->prepare($sqlQuery);
			
			$this->username=htmlspecialchars(strip_tags($this->username));
            $stmt->bindParam(":username", $this->username);
			
            $stmt->execute();
			
            return $stmt;
        }
		
		//check if user exists
		public function existUser(){
            $sqlQuery = "SELECT * FROM ". $this->db_table ." where username = :username OR email = :email";
            $stmt = $this->conn->prepare($sqlQuery);
			
			$this->email=htmlspecialchars(strip_tags($this->email));
            $this->username=htmlspecialchars(strip_tags($this->username));
			
			$stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":username", $this->username);
			
            $stmt->execute();
			
            return $stmt;
        }
        // CREATE ....insert
        public function createUser(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                         
                        name = :name, 
                        email = :email, 
                        username = :username, 
                        password = :password,
						
						gender = :gender, 
                        age = :age, 
                        country_code = :country_code, 
                        mob_no = :mob_no,
						
						country = :country, 
                        OS = :OS, 
                        device_ID = :device_ID, 
                        device_token = :device_token,
						
						location = :location, 
                        image = :image, 
                        access_mode = :access_mode, 
                        final_otp = :final_otp";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->username=htmlspecialchars(strip_tags($this->username));
            $this->password=htmlspecialchars(strip_tags($this->password));
			
			$this->gender=htmlspecialchars(strip_tags($this->gender));
            $this->age=htmlspecialchars(strip_tags($this->age));
            $this->country_code=htmlspecialchars(strip_tags($this->country_code));
            $this->mob_no=htmlspecialchars(strip_tags($this->mob_no));
			
			$this->country=htmlspecialchars(strip_tags($this->country));
            $this->OS=htmlspecialchars(strip_tags($this->OS));
            $this->device_ID=htmlspecialchars(strip_tags($this->device_ID));
            $this->device_token=htmlspecialchars(strip_tags($this->device_token));
			
			$this->location=htmlspecialchars(strip_tags($this->location));
            $this->image=htmlspecialchars(strip_tags($this->image));
            $this->access_mode=htmlspecialchars(strip_tags($this->access_mode));
            $this->final_otp=htmlspecialchars(strip_tags($this->final_otp));
        
            // bind data
            
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":username", $this->username);
            $stmt->bindParam(":password", $this->password);
			
			$stmt->bindParam(":gender", $this->gender);
            $stmt->bindParam(":age", $this->age);
            $stmt->bindParam(":country_code", $this->country_code);
            $stmt->bindParam(":mob_no", $this->mob_no);
			
			$stmt->bindParam(":country", $this->country);
            $stmt->bindParam(":OS", $this->OS);
            $stmt->bindParam(":device_ID", $this->device_ID);
            $stmt->bindParam(":device_token", $this->device_token);
			
			$stmt->bindParam(":location", $this->location);
            $stmt->bindParam(":image", $this->image);
            $stmt->bindParam(":access_mode", $this->access_mode);
            $stmt->bindParam(":final_otp", $this->final_otp);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // get profile data
        public function getProfile(){
            $sqlQuery = "SELECT * FROM ". $this->db_table ." where user_ID = :user_ID";

            $stmt = $this->conn->prepare($sqlQuery);
			
			$this->user_ID=htmlspecialchars(strip_tags($this->user_ID));
            $stmt->bindParam(":user_ID", $this->user_ID);
			
            $stmt->execute();
			
            return $stmt;
       
		
            
        }        


 // UPDATE Device ID on login using either email or username
        public function updateDevice(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        device_ID = :device_ID
                   WHERE 
                        username = :username OR email = :email";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->device_ID=htmlspecialchars(strip_tags($this->device_ID));
            $this->username=htmlspecialchars(strip_tags($this->username));
			 $this->email=htmlspecialchars(strip_tags($this->email));
            
            // bind data
            $stmt->bindParam(":device_ID", $this->device_ID);
            $stmt->bindParam(":username", $this->username);
			$stmt->bindParam(":email", $this->email);
           
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }



        // UPDATE
        public function updateProfile(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        name = :name, 
                        email = :email, 
                        username = :username, 
                        password = :password,
						
						gender = :gender, 
                        age = :age, 
                        country_code = :country_code, 
                        mob_no = :mob_no,
						
						country = :country, 
                        OS = :OS, 
                        device_ID = :device_ID, 
                        device_token = :device_token,
						
						location = :location, 
                        image = :image, 
                        access_mode = :access_mode, 
                        final_otp = :final_otp
                        
                    WHERE 
                        user_ID = :user_ID";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
		// sanitize
			$this->user_ID=htmlspecialchars(strip_tags($this->user_ID));
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->username=htmlspecialchars(strip_tags($this->username));
            $this->password=htmlspecialchars(strip_tags($this->password));
			
			$this->gender=htmlspecialchars(strip_tags($this->gender));
            $this->age=htmlspecialchars(strip_tags($this->age));
            $this->country_code=htmlspecialchars(strip_tags($this->country_code));
            $this->mob_no=htmlspecialchars(strip_tags($this->mob_no));
			
			$this->country=htmlspecialchars(strip_tags($this->country));
            $this->OS=htmlspecialchars(strip_tags($this->OS));
            $this->device_ID=htmlspecialchars(strip_tags($this->device_ID));
            $this->device_token=htmlspecialchars(strip_tags($this->device_token));
			
			$this->location=htmlspecialchars(strip_tags($this->location));
            $this->image=htmlspecialchars(strip_tags($this->image));
            $this->access_mode=htmlspecialchars(strip_tags($this->access_mode));
            $this->final_otp=htmlspecialchars(strip_tags($this->final_otp));
        
            // bind data
            $stmt->bindParam(":user_ID", $this->user_ID);
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":username", $this->username);
            $stmt->bindParam(":password", $this->password);
			
			$stmt->bindParam(":gender", $this->gender);
            $stmt->bindParam(":age", $this->age);
            $stmt->bindParam(":country_code", $this->country_code);
            $stmt->bindParam(":mob_no", $this->mob_no);
			
			$stmt->bindParam(":country", $this->country);
            $stmt->bindParam(":OS", $this->OS);
            $stmt->bindParam(":device_ID", $this->device_ID);
            $stmt->bindParam(":device_token", $this->device_token);
			
			$stmt->bindParam(":location", $this->location);
            $stmt->bindParam(":image", $this->image);
            $stmt->bindParam(":access_mode", $this->access_mode);
            $stmt->bindParam(":final_otp", $this->final_otp);
        
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deleteUser(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE user_ID = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->user_ID=htmlspecialchars(strip_tags($this->user_ID));
        
            $stmt->bindParam(1, $this->user_ID);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
		
	class abCrypt
{
	
	public $key = '';

	
	public	$encrypt_method = 'AES-256-CBC';

	
	function __construct ( $encryption_key = false )
	{
		if ( $key = hex2bin ( $encryption_key ) )
		{
			$this->key = $key;
		}
		else
		{
			echo "Key in construct does not appear to be HEX-encoded...";
		}
	}

	public function encrypt ( $string )
	{
		$new_iv = bin2hex ( random_bytes ( openssl_cipher_iv_length ( $this->encrypt_method ) ) );

		if ( $encrypted = base64_encode ( openssl_encrypt ( $string, $this->encrypt_method, $this->key, 0, $new_iv ) ) )
		{
			return $new_iv.':'.$encrypted;
		}
		else
		{
			return false;
		}
	}

	public function decrypt ( $string )
	{
		$parts     = explode(':', $string );
		$iv        = $parts[0];
		$encrypted = $parts[1];

		if ( $decrypted = openssl_decrypt ( base64_decode ( $encrypted ), $this->encrypt_method, $this->key, 0, $iv ) )
		{
			return $decrypted;
		}
		else
		{
			return false;
		}
	}
}

?>